﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp_január
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> teljes = new List<string>();
        List<string> kiv = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
            foreach (var i in File.ReadAllLines("nevek.txt"))
            {
                teljes.Add(i);
            }
        }

        private void Teljesnévsor_Click(object sender, RoutedEventArgs e)
        {
            foreach (var i in teljes) 
            {
                neveklista.Items.Add(i);
            }
        }

        private void Aktualisnevsor_Click(object sender, RoutedEventArgs e)
        {
            neveklista.Items.Clear();
            kiv.Clear();
            Random vsz = new Random();
            int i = 1;
            int szam;
            while (i <= 10)
            {
                szam = vsz.Next(1,teljes.Count);
                if (!kiv.Contains(teljes[szam]))
                {
                    kiv.Add(teljes[szam]);
                    i++;
                }
            }
            List<string> napok = new List<string>() {"Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek" };
            int napindex = 0;
            for (int j = 0; j < kiv.Count; j = j + 2)
            {
                neveklista.Items.Add(napok[napindex] + ":" + kiv[j] + "," + kiv[j + 1]);
                napindex++;
            }
        }

        private void Fajlbair_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter f = new StreamWriter("ugyeletilista.txt");
            f.WriteLine("Aktuális ügyeleti lista:");
            foreach(var i in kiv)
            {
                f.WriteLine(i);
            }
            f.Close();
            MessageBox.Show("Sikeres fájlbaírás!");
        }
    }
}
